# Boostball Arena

A procedural 3D browser vehicular-soccer prototype built with Three.js and Rapier3D. No downloaded game art or sound assets are required.

## Run locally
- Install Node.js 20+
- `npm install`
- `npm run dev`
- Open the local Vite URL in a WebGL2-capable desktop browser.

## Controls
- **WASD / Arrow keys** — drive and steer
- **Space** — jump, then directional dodge / flip
- **Shift** — boost
- **Q / E** — air roll; **I / K** pitch; **J / L** yaw
- **C** — toggle ball cam
- **R / Backspace** — reset car and ball
- **F2** — freeplay training panel
- **F3** — TAS / replay dock
- **F5 / F7** — save / load physics state (slot 1)
- Standard Gamepad API — left stick steer/throttle, south face button jump, right trigger boost

## Included
- Rapier fixed 120 Hz simulation loop, dynamic car and ball bodies, spring/damper chassis support, lateral tire grip, air control, jump/dodge, boost and ball spin curve force.
- Enclosed arena, open goal mouths, procedural goal frames, center markings, translucent stadium walls, pads and target ring.
- Ball cam / car cam, speed + boost HUD, training shots, physics modifiers, JSON training shot export/import, hitbox toggle setting, trajectory predictor.
- TAS pause, single-tick stepping, input recording and replay, timeline scrubbing with checkpoint restore + deterministic input re-simulation, per-frame throttle/steer/air-control/jump/boost editing, JSON import/export, and five physics save-state slots (F5/F7 use the selected slot).

## Project structure
`src/physics.js` — Rapier world and rigid bodies  
`src/car.js` — car mesh and vehicle control  
`src/camera.js` — follow / ball camera  
`src/bakkesmod.js` — freeplay training tools and shot JSON  
`src/tas.js` — tick recorder and state snapshots  
`src/ui.js` — HUD, panels and keyboard bindings  
`src/main.js` — scene, render loop, stadium and integration

## Prototype notes
This is an arcade-sim starting point, not a full Rocket League clone. The suspension is a lightweight four-point spring/damper approximation rather than a complete tire raycast vehicle solver; the arena's curved transitions are visual accents with simplified rectangular collision boundaries. TAS replay re-simulates recorded inputs from the nearest 120-tick checkpoint; edits invalidate later checkpoints so the edited segment is re-simulated from the prior valid checkpoint. Determinism is scoped to the current single-player simulation and same browser/runtime version; this is not a cross-version deterministic guarantee. Collision hitbox display, boost trail/skid-mark particles, goal burst particles, and persistent pad visual indicators are planned extensions. Browser gamepad layouts vary by controller and browser.
