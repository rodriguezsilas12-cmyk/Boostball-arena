import * as THREE from 'three';
export class FollowCamera{
 constructor(camera){this.camera=camera;this.ballCam=true;this.distance=8.5;this.height=3.4;this.angle=0;this.stiffness=5.5;this.fov=78;this.look=new THREE.Vector3();}
 update(car,ball,dt){const forward=new THREE.Vector3(0,0,-1).applyQuaternion(car.quaternion);const target=car.position.clone();let desired;
  if(this.ballCam){const b=ball.position.clone();const aim=b.clone().sub(target);if(aim.lengthSq()<.1)aim.copy(forward);aim.normalize();desired=target.clone().addScaledVector(aim,-this.distance).add(new THREE.Vector3(0,this.height,0));this.look.lerp(b.clone().add(new THREE.Vector3(0,.4,0)),1-Math.exp(-this.stiffness*dt));}
  else{desired=target.clone().addScaledVector(forward,-this.distance).add(new THREE.Vector3(0,this.height,0));this.look.lerp(target.clone().addScaledVector(forward,5).add(new THREE.Vector3(0,1,0)),1-Math.exp(-this.stiffness*dt));}
  this.camera.position.lerp(desired,1-Math.exp(-this.stiffness*dt));this.camera.lookAt(this.look);}
}
