import RAPIER from '@dimforge/rapier3d-compat';

export const FIXED_DT = 1 / 120;
export async function createPhysics() {
  await RAPIER.init();
  const world = new RAPIER.World({ x: 0, y: -9.81, z: 0 });
  world.timestep = FIXED_DT;
  world.integrationParameters.numSolverIterations = 8;
  world.integrationParameters.numInternalPgsIterations = 2;
  const groundBody = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
  world.createCollider(RAPIER.ColliderDesc.cuboid(18, .5, 27).setTranslation(0, -.5, 0).setFriction(1.3).setRestitution(.15), groundBody);
  // Side walls, end walls and ceiling. Goal mouths are visually recessed; these rails keep freeplay contained.
  for (const x of [-18.5, 18.5]) {
    const b = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
    world.createCollider(RAPIER.ColliderDesc.cuboid(.5, 8, 27).setTranslation(x, 7.5, 0).setFriction(.8).setRestitution(.72), b);
  }
  for (const z of [-27.5, 27.5]) {
    for (const x of [-12.5, 12.5]) {
      const b = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
      world.createCollider(RAPIER.ColliderDesc.cuboid(5.5, 8, .5).setTranslation(x, 7.5, z).setFriction(.8).setRestitution(.72), b);
    }
    const crossbar = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
    world.createCollider(RAPIER.ColliderDesc.cuboid(7, .5, .5).setTranslation(0, 12, z).setFriction(.8).setRestitution(.72), crossbar);
  }
  const roof = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
  world.createCollider(RAPIER.ColliderDesc.cuboid(18, .5, 27).setTranslation(0, 15.5, 0).setFriction(.8).setRestitution(.7), roof);
  const ballBody = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0, 2.2, -3).setLinearDamping(.04).setAngularDamping(.06).setCcdEnabled(true));
  const ballCollider = world.createCollider(RAPIER.ColliderDesc.ball(1.35).setDensity(.22).setFriction(.65).setRestitution(.82), ballBody);
  const carBody = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0, 1.25, 9).setCanSleep(false).setLinearDamping(.08).setAngularDamping(1.5).setCcdEnabled(true));
  const carCollider = world.createCollider(RAPIER.ColliderDesc.cuboid(.92, .38, 1.45).setDensity(1.15).setFriction(1.15).setRestitution(.18), carBody);
  const pads = [];
  for (const [x,z,big] of [[-12,-18,false],[12,-18,false],[-12,0,false],[12,0,false],[-12,18,false],[12,18,false],[-15,-23,true],[15,-23,true],[-15,23,true],[15,23,true]]) {
    const body = world.createRigidBody(RAPIER.RigidBodyDesc.fixed().setTranslation(x,.08,z));
    const collider = world.createCollider(RAPIER.ColliderDesc.ball(big?.75:.5).setSensor(true), body);
    pads.push({body, collider, big, active:true, position:{x,y:.08,z}, respawn:0});
  }
  return { RAPIER, world, carBody, carCollider, ballBody, ballCollider, pads, groundBody };
}

export function vec(v) { return {x:v.x,y:v.y,z:v.z}; }
export function bodySnapshot(body) {
  const p=body.translation(), q=body.rotation(), v=body.linvel(), w=body.angvel();
  return {p:vec(p),q:{x:q.x,y:q.y,z:q.z,w:q.w},v:vec(v),w:vec(w)};
}
export function restoreBody(body,s) {
  body.setTranslation(s.p,true); body.setRotation(s.q,true); body.setLinvel(s.v,true); body.setAngvel(s.w,true);
  body.wakeUp();
}
