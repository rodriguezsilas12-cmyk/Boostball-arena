import {bodySnapshot,restoreBody} from './physics.js';

const clone = value => JSON.parse(JSON.stringify(value));

export class TASController {
  constructor(physics, car, {getSettings=()=>({}), setSettings=()=>{}}={}) {
    this.physics=physics; this.car=car; this.getSettings=getSettings; this.setSettings=setSettings;
    this.paused=false; this.recording=false; this.playback=false;
    this.frames=[]; this.cursor=0; this.tick=0; this.checkpoints=[]; this.slots=Array(5).fill(null); this.slot=0;
    this.maxFrames=12000; this.checkpointEvery=120;
  }
  snapshot() {
    return {tick:this.tick,car:bodySnapshot(this.physics.carBody),ball:bodySnapshot(this.physics.ballBody),
      carState:{boost:this.car.boost,jumpReady:this.car.jumpReady,doubleReady:this.car.doubleReady,jumpTimer:this.car.jumpTimer,grounded:this.car.grounded,lastJump:this.car.lastJump,wheelSpin:this.car.wheelSpin},
      pads:this.physics.pads.map(p=>({active:p.active,respawn:p.respawn})),settings:clone(this.getSettings())};
  }
  restore(s) {
    if(!s)return false;
    restoreBody(this.physics.carBody,s.car);restoreBody(this.physics.ballBody,s.ball);Object.assign(this.car,s.carState);
    s.pads.forEach((p,i)=>{if(this.physics.pads[i])Object.assign(this.physics.pads[i],p);});
    this.setSettings(clone(s.settings||{}));this.tick=s.tick;return true;
  }
  saveState(slot=this.slot) {this.slot=Math.max(0,Math.min(4,slot|0));const s=this.snapshot();this.slots[this.slot]=clone(s);return s;}
  loadState(slot=this.slot) {this.slot=Math.max(0,Math.min(4,slot|0));const s=this.slots[this.slot];if(!s)return false;this.playback=false;this.recording=false;this.paused=true;return this.restore(clone(s));}
  startRecording() {this.frames=[];this.checkpoints=[];this.cursor=0;this.playback=false;this.recording=true;this.paused=false;this.checkpoints.push({frameIndex:0,state:this.snapshot()});}
  stopRecording(){this.recording=false;}
  capture(input,settings) {
    if(this.recording&&!this.playback){this.frames.push({tick:this.tick,input:clone(input),settings:clone(settings)});if(this.frames.length>this.maxFrames)this.frames.shift();this.cursor=this.frames.length;}
    this.tick++;
    if(this.recording&&!this.playback&&this.frames.length%this.checkpointEvery===0)this.checkpoints.push({frameIndex:this.frames.length,state:this.snapshot()});
  }
  startPlayback(){if(!this.frames.length)return false;this.recording=false;if(this.cursor>=this.frames.length)this.cursor=0;this.playback=true;this.paused=false;return true;}
  stopPlayback(){this.playback=false;this.paused=true;}
  nextPlaybackInput(){if(!this.playback)return null;if(this.cursor>=this.frames.length){this.stopPlayback();return null;}const f=this.frames[this.cursor++];this.setSettings(clone(f.settings||{}));return f.input;}
  step(){this.paused=true;this.playback=false;return true;}
  seek(index,simulateStep){if(!this.frames.length)return false;this.recording=false;this.playback=false;const target=Math.max(0,Math.min(this.frames.length,index|0));const cp=[...this.checkpoints].reverse().find(c=>c.frameIndex<=target)||this.checkpoints[0];if(!cp?.state)return false;this.restore(clone(cp.state));for(let i=cp.frameIndex;i<target;i++){const f=this.frames[i];if(!f)break;this.setSettings(clone(f.settings||{}));simulateStep(clone(f.input),true);}this.cursor=target;this.playback=false;this.paused=true;return true;}
  editFrame(index,patch){if(index<0||index>=this.frames.length)return false;this.frames[index].input={...this.frames[index].input,...patch};this.checkpoints=this.checkpoints.filter(c=>c.frameIndex<=index);return true;}
  export(){return new Blob([JSON.stringify({format:'boostball-tas-v2',tickRate:120,frames:this.frames,checkpoints:this.checkpoints,slots:this.slots,metadata:{frameCount:this.frames.length,createdAt:new Date().toISOString()}},null,2)],{type:'application/json'});}
  importData(data){if(!data||!Array.isArray(data.frames)||!['boostball-tas-v2','boostball-inputs-v1'].includes(data.format))throw new Error('Unsupported Boostball TAS file.');this.frames=data.frames.map((f,i)=>({tick:Number.isFinite(f.tick)?f.tick:i,input:clone(f.input||f),settings:clone(f.settings||this.getSettings())}));this.checkpoints=Array.isArray(data.checkpoints)?data.checkpoints:[];this.slots=Array.isArray(data.slots)?data.slots.slice(0,5):this.slots;while(this.slots.length<5)this.slots.push(null);if(!this.checkpoints.length)this.checkpoints.push({frameIndex:0,state:this.snapshot()});this.cursor=0;this.recording=false;this.playback=false;this.paused=true;return this.frames.length;}
}
