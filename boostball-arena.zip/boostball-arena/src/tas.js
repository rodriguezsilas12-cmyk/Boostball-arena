import {bodySnapshot,restoreBody} from './physics.js';
export class TASController{
 constructor(physics,car){this.physics=physics;this.car=car;this.paused=false;this.recording=false;this.frames=[];this.cursor=0;this.tick=0;this.states=[];this.slot=0;this.maxFrames=12000;}
 capture(input){if(this.recording){this.frames.push({...input,tick:this.tick});if(this.frames.length>this.maxFrames)this.frames.shift();this.cursor=this.frames.length;}this.tick++;}
 step(){this.paused=true;return true;}
 saveState(){const pads=this.physics.pads.map(p=>({active:p.active,respawn:p.respawn}));const s={tick:this.tick,car:bodySnapshot(this.physics.carBody),ball:bodySnapshot(this.physics.ballBody),boost:this.car.boost,pads};this.states[this.slot]=s;return s;}
 loadState(){const s=this.states[this.slot];if(!s)return false;restoreBody(this.physics.carBody,s.car);restoreBody(this.physics.ballBody,s.ball);this.car.boost=s.boost;s.pads.forEach((p,i)=>{this.physics.pads[i].active=p.active;this.physics.pads[i].respawn=p.respawn;});this.tick=s.tick;return true;}
 export(){return new Blob([JSON.stringify({format:'boostball-inputs-v1',tickRate:120,frames:this.frames},null,2)],{type:'application/json'});}
 seek(index){this.cursor=Math.max(0,Math.min(this.frames.length,index));return this.frames[this.cursor]||null;}
}
