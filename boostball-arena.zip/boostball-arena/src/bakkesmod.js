import * as THREE from 'three';
export class TrainingTools{
 constructor({physics,car,ball,ballMesh,scene}){Object.assign(this,{physics,car,ball,ballMesh,scene});this.settings={gameSpeed:1,gravityScale:1,bounce:.82,unlimitedBoost:false,hitboxes:false,predictor:false};this.shots=[];this.hitboxHelpers=[];this.prediction=null;}
 setShot(kind){const p=this.car.body.translation(),v=this.car.body.linvel();const bp=this.ball.translation();
  if(kind==='dribble'){this.ball.setTranslation({x:p.x,y:p.y+2.35,z:p.z-1.7},true);this.ball.setLinvel({x:v.x,y:1.2,z:v.z-1},true);}
  if(kind==='pass'){const dir=new THREE.Vector3(p.x-bp.x,0,p.z-bp.z).normalize();this.ball.setLinvel({x:dir.x*12,y:2,z:dir.z*12},true);}
  if(kind==='wall'){const side=p.x>=0?-1:1;this.ball.setTranslation({x:side*13,y:1.5,z:p.z-5},true);this.ball.setLinvel({x:side*5,y:1,z:-4},true);}
  if(kind==='defend'){const ownZ=p.z>=0?25:-25;this.ball.setTranslation({x:0,y:2,z:-ownZ*.65},true);this.ball.setLinvel({x:(Math.random()-.5)*2,y:2,z:Math.sign(ownZ)*19},true);}
 }
 reset(){this.car.reset();this.ball.setTranslation({x:0,y:2.2,z:-3},true);this.ball.setLinvel({x:0,y:0,z:0},true);this.ball.setAngvel({x:0,y:0,z:0},true);this.physics.pads.forEach(p=>{p.active=true;p.respawn=0;});}
 updatePads(dt,car){const p=car.body.translation();for(const pad of this.physics.pads){if(!pad.active){pad.respawn-=dt;if(pad.respawn<=0)pad.active=true;continue;}const dx=p.x-pad.position.x,dz=p.z-pad.position.z;if(dx*dx+dz*dz<2.1&&Math.abs(p.y- pad.position.y)<2.2){car.refill(pad.big?100:12);pad.active=false;pad.respawn=pad.big?10:4;}}
 }
 saveShot(name){const shot={name:name||'Training Shot',car:{p:this.physics.carBody.translation(),q:this.physics.carBody.rotation(),v:this.physics.carBody.linvel(),w:this.physics.carBody.angvel(),boost:this.car.boost},ball:{p:this.ball.translation(),q:this.ball.rotation(),v:this.ball.linvel(),w:this.ball.angvel()}};return new Blob([JSON.stringify(shot,null,2)],{type:'application/json'});}
 loadShot(data){if(!data?.car?.p||!data?.ball?.p)throw new Error('Invalid training shot');const apply=(b,s)=>{b.setTranslation(s.p,true);if(s.q)b.setRotation(s.q,true);b.setLinvel(s.v||{x:0,y:0,z:0},true);b.setAngvel(s.w||{x:0,y:0,z:0},true);};apply(this.physics.carBody,data.car);apply(this.ball,data.ball);this.car.boost=data.car.boost??100;}
}
