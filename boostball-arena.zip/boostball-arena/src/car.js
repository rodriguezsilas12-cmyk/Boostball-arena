import * as THREE from 'three';

const UP = new THREE.Vector3(0,1,0);
export class CarController {
  constructor(body, mesh, physics) { this.body=body; this.mesh=mesh; this.physics=physics; this.boost=100; this.jumpReady=true; this.doubleReady=true; this.jumpTimer=0; this.grounded=false; this.steer=0; this.throttle=0; this.airControl=1; this.lastJump=false; this.wheelSpin=0; }
  getForward(){ return new THREE.Vector3(0,0,-1).applyQuaternion(this.mesh.quaternion).normalize(); }
  getRight(){ return new THREE.Vector3(1,0,0).applyQuaternion(this.mesh.quaternion).normalize(); }
  update(input, dt, settings) {
    const b=this.body, pos=b.translation(), q=b.rotation();
    this.mesh.position.set(pos.x,pos.y,pos.z); this.mesh.quaternion.set(q.x,q.y,q.z,q.w);
    const forward=this.getForward(), right=this.getRight(), up=new THREE.Vector3(0,1,0).applyQuaternion(this.mesh.quaternion).normalize();
    const vel=b.linvel(), velocity=new THREE.Vector3(vel.x,vel.y,vel.z);
    this.grounded=false;
    const throttle=input.throttle||0, steer=input.steer||0;
    this.throttle=throttle; this.steer=steer;
    const speed=velocity.dot(forward);
    const driveForce=throttle*(speed<27?145:Math.max(18,145-(speed-27)*5));
    b.applyForce({x:forward.x*driveForce,y:0,z:forward.z*driveForce},true);
    const sideSpeed=velocity.dot(right);
    b.applyForce({x:-right.x*sideSpeed* (this.grounded?15:1.7),y:0,z:-right.z*sideSpeed*(this.grounded?15:1.7)},true);
    const yawTorque=steer*(this.grounded?34:8)*THREE.MathUtils.clamp(Math.abs(speed)/8,.25,1.6);
    b.applyTorque({x:0,y:yawTorque,z:0},true);
    // Four downward wheel rays drive spring-damper suspension forces at their hit points.
    for(const sx of [-.68,.68]) for(const sz of [-1.02,1.02]){
      const anchor=new THREE.Vector3(sx,-.28,sz).applyQuaternion(this.mesh.quaternion).add(this.mesh.position);
      const ray=new this.physics.RAPIER.Ray({x:anchor.x,y:anchor.y,z:anchor.z},{x:0,y:-1,z:0});
      const hit=this.physics.world.castRay(ray,1.12,true,undefined,undefined,undefined,b);
      if(hit){
        this.grounded=true;
        const hitPoint={x:anchor.x,y:anchor.y-hit.toi,z:anchor.z};
        const pointVel=b.velocityAtPoint(hitPoint);
        const compression=Math.max(0,1.12-hit.toi);
        const spring=Math.max(0,compression*950-pointVel.y*95);
        b.applyForceAtPoint({x:0,y:spring,z:0},hitPoint,true);
      }
    }
    if(this.grounded){
      // Grounded attitude stabilizer and lateral grip.
      b.applyTorque({x:-this.mesh.rotation.x*17,y:0,z:-this.mesh.rotation.z*17},true);
    }
    if(input.boost && (this.boost>0 || settings.unlimitedBoost)){
      b.applyForce({x:forward.x*255,y:forward.y*255,z:forward.z*255},true);
      if(!settings.unlimitedBoost) this.boost=Math.max(0,this.boost-34*dt);
    }
    if(input.jump && !this.lastJump){
      if(this.grounded && this.jumpReady){ b.applyImpulse({x:0,y:5.5,z:0},true); this.jumpReady=false; this.jumpTimer=0; }
      else if(!this.grounded && this.doubleReady){
        const dir=new THREE.Vector3(input.dodgeX||0,input.dodgeY||0,input.dodgeZ||1);
        if(dir.lengthSq()<.01) dir.set(0,0,1); dir.normalize().applyQuaternion(this.mesh.quaternion);
        b.setLinvel({x:vel.x*.35,y:Math.max(0,vel.y)*.25,z:vel.z*.35},true);
        b.applyImpulse({x:dir.x*8,y:dir.y*6+2,z:dir.z*8},true);
        b.applyTorqueImpulse({x:-dir.z*3,y:0,z:dir.x*3},true); this.doubleReady=false;
      }
    }
    this.lastJump=!!input.jump;
    if(this.grounded){this.jumpReady=true;this.doubleReady=true;}
    if(!this.grounded){
      b.applyTorque({x:(input.pitch||0)*13,y:(input.yaw||0)*9,z:(input.roll||0)*15},true);
    }
    this.wheelSpin += speed*dt*1.8;
    if(this.mesh.userData.wheels) this.mesh.userData.wheels.forEach(w=>w.rotation.x=this.wheelSpin);
    this.mesh.position.set(pos.x,pos.y,pos.z); this.mesh.quaternion.set(q.x,q.y,q.z,q.w);
  }
  refill(amount){this.boost=Math.min(100,this.boost+amount);}
  reset(){this.body.setTranslation({x:0,y:1.25,z:9},true);this.body.setRotation({x:0,y:0,z:0,w:1},true);this.body.setLinvel({x:0,y:0,z:0},true);this.body.setAngvel({x:0,y:0,z:0},true);this.boost=100;this.jumpReady=true;this.doubleReady=true;}
}

export function createCarMesh(THREE){
  const root=new THREE.Group();
  const bodyMat=new THREE.MeshStandardMaterial({color:0x23c9e8,metalness:.72,roughness:.26});
  const dark=new THREE.MeshStandardMaterial({color:0x101a2c,metalness:.5,roughness:.35});
  const glass=new THREE.MeshStandardMaterial({color:0x102d46,metalness:.65,roughness:.14,emissive:0x06253a});
  const chassis=new THREE.Mesh(new THREE.BoxGeometry(1.75,.48,2.7),bodyMat);chassis.position.y=.1;root.add(chassis);
  const hood=new THREE.Mesh(new THREE.BoxGeometry(1.55,.2,.9),bodyMat);hood.position.set(0,.34,-.75);root.add(hood);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.25,.52,1.05),glass);cabin.position.set(0,.52,.15);root.add(cabin);
  const spoiler=new THREE.Mesh(new THREE.BoxGeometry(1.8,.08,.22),dark);spoiler.position.set(0,.58,1.18);root.add(spoiler);
  const bumper=new THREE.Mesh(new THREE.BoxGeometry(1.8,.2,.18),dark);bumper.position.set(0,-.08,-1.36);root.add(bumper);
  const wheels=[];
  for(const x of [-.82,.82])for(const z of [-.85,.9]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.34,.34,.22,16),dark);w.rotation.z=Math.PI/2;w.position.set(x,-.18,z);root.add(w);wheels.push(w);}
  const glow=new THREE.PointLight(0x37dfff,2,5);glow.position.set(0,.1,-1.5);root.add(glow);
  root.userData.wheels=wheels;return root;
}
