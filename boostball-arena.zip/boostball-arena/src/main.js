import * as THREE from 'three';
import './style.css';
import {createPhysics,FIXED_DT} from './physics.js';
import {CarController,createCarMesh} from './car.js';
import {FollowCamera} from './camera.js';
import {TrainingTools} from './bakkesmod.js';
import {TASController} from './tas.js';
import {bindUI} from './ui.js';

const physics=await createPhysics();
const {world,carBody,ballBody,pads}=physics;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x07101e);scene.fog=new THREE.FogExp2(0x07101e,.009);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;document.getElementById('app').prepend(renderer.domElement);
const camera=new THREE.PerspectiveCamera(78,innerWidth/innerHeight,.1,180);const followCam=new FollowCamera(camera);
scene.add(new THREE.HemisphereLight(0x8abfff,0x111b2c,1.65));
const key=new THREE.DirectionalLight(0xd8f3ff,2.3);key.position.set(-12,24,8);key.castShadow=true;key.shadow.mapSize.set(2048,2048);key.shadow.camera.left=-35;key.shadow.camera.right=35;key.shadow.camera.top=35;key.shadow.camera.bottom=-35;scene.add(key);
const fill=new THREE.PointLight(0x22cfff,90,65);fill.position.set(0,11,0);scene.add(fill);
const orangeLight=new THREE.PointLight(0xff8b4b,65,35);orangeLight.position.set(0,8,-23);scene.add(orangeLight);
const blueLight=new THREE.PointLight(0x35bfff,65,35);blueLight.position.set(0,8,23);scene.add(blueLight);

function mat(color,rough=.6,metal=0,emissive=0){return new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal,emissive,emissiveIntensity:.6});}
const floor=new THREE.Mesh(new THREE.PlaneGeometry(36,54),mat(0x142b3a,.82));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor);
const floorLines=new THREE.Group();scene.add(floorLines);
function line(points,color=0x2b8ba5,opacity=.6){const g=new THREE.BufferGeometry().setFromPoints(points);const m=new THREE.LineBasicMaterial({color,transparent:true,opacity});const l=new THREE.Line(g,m);floorLines.add(l);return l;}
line([new THREE.Vector3(-17.7,.025,0),new THREE.Vector3(17.7,.025,0)],0x42b8d0,.65);
const circle=new THREE.Mesh(new THREE.RingGeometry(4.8,4.88,80),new THREE.MeshBasicMaterial({color:0x43c9e6,transparent:true,opacity:.7,side:THREE.DoubleSide}));circle.rotation.x=-Math.PI/2;circle.position.y=.03;scene.add(circle);
for(const z of [-18,-12,-6,6,12,18]){line([new THREE.Vector3(-17,.02,z),new THREE.Vector3(17,.02,z)],0x2a586c,.24);}
const wallMat=new THREE.MeshStandardMaterial({color:0x102b40,metalness:.5,roughness:.28,transparent:true,opacity:.5,side:THREE.DoubleSide});
function addWall(x,y,z,sx,sy,sz,rot=0){const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),wallMat);m.position.set(x,y,z);m.rotation.z=rot;m.receiveShadow=true;scene.add(m);return m;}
addWall(-18.25,7.5,0,.5,15,54);addWall(18.25,7.5,0,.5,15,54);
// Stadium end walls have open central goal mouths.
for(const z of [-27.25,27.25]){addWall(-12.5,7.5,z,11,15,.5);addWall(12.5,7.5,z,11,15,.5);addWall(0,12,z,14,7,.5);}
const roof=new THREE.Mesh(new THREE.PlaneGeometry(36,54),new THREE.MeshBasicMaterial({color:0x14304a,wireframe:true,transparent:true,opacity:.12,side:THREE.DoubleSide}));roof.rotation.x=Math.PI/2;roof.position.y=15.3;scene.add(roof);
// Curved transition accents along the pitch edges.
for(const side of [-1,1]){const pts=[];for(let i=0;i<=32;i++){const t=i/32*Math.PI/2;pts.push(new THREE.Vector3(side*(15.2+2.7*Math.sin(t)),2.7*(1-Math.cos(t)), -27+i/32*54));}line(pts,0x37d7f0,.35);}
function makeGoal(z,color){const group=new THREE.Group();const frame=mat(color,.3,.55,color);for(const x of [-5.5,5.5]){const post=new THREE.Mesh(new THREE.BoxGeometry(.25,5.2,.35),frame);post.position.set(x,2.6,0);group.add(post);}const bar=new THREE.Mesh(new THREE.BoxGeometry(11,.25,.35),frame);bar.position.y=5.2;group.add(bar);const net=new THREE.Mesh(new THREE.BoxGeometry(10.8,5,.08),new THREE.MeshBasicMaterial({color,wireframe:true,transparent:true,opacity:.22}));net.position.set(0,2.5,3);group.add(net);group.position.z=z;scene.add(group);}
makeGoal(-26.4,0xff995c);makeGoal(26.4,0x5bdfff);

const carMesh=createCarMesh(THREE);carMesh.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});scene.add(carMesh);
const carHitbox=new THREE.Mesh(new THREE.BoxGeometry(1.84,.76,2.9),new THREE.MeshBasicMaterial({color:0x75f0ff,wireframe:true,transparent:true,opacity:.75}));scene.add(carHitbox);
const ballHitbox=new THREE.Mesh(new THREE.SphereGeometry(1.38,12,8),new THREE.MeshBasicMaterial({color:0xffb36b,wireframe:true,transparent:true,opacity:.55}));scene.add(ballHitbox);
const car=new CarController(carBody,carMesh,physics);
const ballMesh=new THREE.Mesh(new THREE.SphereGeometry(1.35,32,24),new THREE.MeshStandardMaterial({color:0xe8f0f5,roughness:.35,metalness:.15}));ballMesh.castShadow=true;scene.add(ballMesh);
const ballEdges=new THREE.Mesh(new THREE.SphereGeometry(1.355,16,12),new THREE.MeshBasicMaterial({color:0x56dfff,wireframe:true,transparent:true,opacity:.13}));ballMesh.add(ballEdges);
const target=new THREE.Mesh(new THREE.RingGeometry(1.5,1.62,48),new THREE.MeshBasicMaterial({color:0x5de6ff,transparent:true,opacity:.9,side:THREE.DoubleSide}));target.rotation.x=-Math.PI/2;scene.add(target);
const padMeshes=[];
for(const p of pads){const group=new THREE.Group();const disc=new THREE.Mesh(new THREE.CylinderGeometry(p.big?.8:.48,p.big?.8:.48,.08,24),new THREE.MeshStandardMaterial({color:p.big?0xffb45b:0x43c9e8,emissive:p.big?0x9a4b12:0x075b78,emissiveIntensity:1.6,metalness:.5,roughness:.25}));disc.position.y=.13;group.add(disc);const ring=new THREE.Mesh(new THREE.TorusGeometry(p.big?.85:.53,.035,8,32),new THREE.MeshBasicMaterial({color:p.big?0xffbd68:0x65eaff}));ring.rotation.x=Math.PI/2;ring.position.y=.2;group.add(ring);group.position.set(p.position.x,0,p.position.z);scene.add(group);padMeshes.push(group);}
const training=new TrainingTools({physics,car,ball:ballBody,ballMesh,scene});
const tas=new TASController(physics,car);
let paused=false,ballCam=true,accumulator=0,tick=0,blueScore=0,orangeScore=0,lastGoal=0;
const ui=bindUI({training,tas,onPause:()=>{paused=!paused;document.getElementById('pause-btn').textContent=paused?'▶':'Ⅱ';},onBallCam:()=>{ballCam=!ballCam;followCam.ballCam=ballCam;},onReset:()=>training.reset()});

const keys={};window.addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();});window.addEventListener('keyup',e=>keys[e.code]=false);
function inputState(){let gp=navigator.getGamepads?.()[0],axis=(i)=>gp?.axes?.[i]||0,button=(i)=>gp?.buttons?.[i]?.pressed||false;
 const throttle=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0);const steer=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0);
 return {throttle:Math.abs(axis(1))>.12?-axis(1):throttle,steer:Math.abs(axis(0))>.12?axis(0):steer,boost:!!(keys.ShiftLeft||keys.ShiftRight||button(boostIndex(gp))),jump:!!(keys.Space||button(0)),pitch:(keys.KeyI?1:0)-(keys.KeyK?1:0),yaw:(keys.KeyL?1:0)-(keys.KeyJ?1:0),roll:(keys.KeyE?1:0)-(keys.KeyQ?1:0),dodgeX:steer,dodgeY:0,dodgeZ:throttle};}
function boostIndex(gp){return gp?.mapping==='standard'?7:7;}
const predictorLine=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineDashedMaterial({color:0x7beaff,dashSize:.35,gapSize:.22,transparent:true,opacity:.65}));scene.add(predictorLine);
const carPredictor=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineDashedMaterial({color:0xffc078,dashSize:.25,gapSize:.2,transparent:true,opacity:.5}));scene.add(carPredictor);
function updatePredictor(){if(!training.settings.predictor){predictorLine.visible=false;carPredictor.visible=false;return;}predictorLine.visible=carPredictor.visible=true;const p=ballBody.translation(),v=ballBody.linvel(),pts=[],carPts=[],cp=carBody.translation(),cv=carBody.linvel();for(let i=0;i<=45;i++){const t=i/30;pts.push(new THREE.Vector3(p.x+v.x*t,p.y+v.y*t-4.905*t*t,p.z+v.z*t));carPts.push(new THREE.Vector3(cp.x+cv.x*t,cp.y+cv.y*t-4.905*t*t,cp.z+cv.z*t));}predictorLine.geometry.dispose();predictorLine.geometry.setFromPoints(pts);predictorLine.computeLineDistances();carPredictor.geometry.dispose();carPredictor.geometry.setFromPoints(carPts);carPredictor.computeLineDistances();}
function checkGoal(){const p=ballBody.translation();if(Math.abs(p.z)>25.8&&Math.abs(p.x)<5.7&&p.y<5.5&&performance.now()-lastGoal>1500){if(p.z<0)blueScore++;else orangeScore++;document.getElementById('blue-score').textContent=blueScore;document.getElementById('orange-score').textContent=orangeScore;lastGoal=performance.now();const flash=document.getElementById('goal-flash');flash.classList.remove('active');void flash.offsetWidth;flash.classList.add('active');ballBody.setTranslation({x:0,y:2.2,z:0},true);ballBody.setLinvel({x:0,y:0,z:0},true);ballBody.setAngvel({x:0,y:0,z:0},true);}}
function syncVisuals(dt){const cp=carBody.translation(),cq=carBody.rotation(),bp=ballBody.translation(),bq=ballBody.rotation();carMesh.position.set(cp.x,cp.y,cp.z);carMesh.quaternion.set(cq.x,cq.y,cq.z,cq.w);carHitbox.position.copy(carMesh.position);carHitbox.quaternion.copy(carMesh.quaternion);ballMesh.position.set(bp.x,bp.y,bp.z);ballMesh.quaternion.set(bq.x,bq.y,bq.z,bq.w);ballHitbox.position.copy(ballMesh.position);ballHitbox.visible=training.settings.hitboxes;carHitbox.visible=training.settings.hitboxes;const h=Math.max(0,bp.y-1.35);target.position.set(bp.x,.035,bp.z);target.scale.setScalar(1+Math.min(h,12)*.035);target.material.color.setHSL(.52-h*.025,.9,.58);target.material.opacity=Math.max(.18,1-h*.055);padMeshes.forEach((m,i)=>{m.visible=pads[i].active;m.rotation.y+=dt*(pads[i].big?.8:1.4);});followCam.update(carMesh,ballMesh,dt);}
function physicsStep(input){world.gravity={x:0,y:-9.81*training.settings.gravityScale,z:0};physics.ballCollider.setRestitution(training.settings.bounce);car.update(input,FIXED_DT,training.settings);
 const bv=ballBody.linvel(),av=ballBody.angvel();const vel=new THREE.Vector3(bv.x,bv.y,bv.z),spin=new THREE.Vector3(av.x,av.y,av.z);const magnus=new THREE.Vector3().crossVectors(spin,vel).multiplyScalar(.018);ballBody.applyForce({x:magnus.x,y:magnus.y,z:magnus.z},true);
 world.step();training.updatePads(FIXED_DT,car);tas.capture(input);tick++;checkGoal();}
let last=performance.now();function animate(now){requestAnimationFrame(animate);const realDt=Math.min(.05,(now-last)/1000);last=now;let input=inputState();if(!paused&&!tas.paused){accumulator+=realDt*training.settings.gameSpeed;let steps=0;while(accumulator>=FIXED_DT&&steps<16){physicsStep(input);accumulator-=FIXED_DT;steps++;}}else{accumulator=0;}
 syncVisuals(realDt);updatePredictor();const v=carBody.linvel();ui.update({speed:Math.hypot(v.x,v.y,v.z),boost:car.boost,car:carBody,tick});
 renderer.render(scene,camera);}
window.addEventListener('tas-step',()=>{const input=inputState();physicsStep(input);syncVisuals(FIXED_DT);});
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
window.addEventListener('keydown',e=>{if(e.code==='F5'){e.preventDefault();tas.slot=0;tas.saveState();}if(e.code==='F7'){e.preventDefault();tas.slot=0;tas.loadState();}});
followCam.ballCam=ballCam;document.getElementById('center-message').classList.add('show');setTimeout(()=>document.getElementById('center-message').classList.remove('show'),2600);
requestAnimationFrame(animate);
