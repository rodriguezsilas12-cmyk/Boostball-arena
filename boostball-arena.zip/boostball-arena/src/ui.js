export function bindUI({training,tas,onPause,onBallCam,onReset,onSeek,onStep}){
 const $=id=>document.getElementById(id);
 const show=id=>$(id).classList.remove('hidden'),hide=id=>$(id).classList.add('hidden');
 const download=(blob,name)=>{const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>hide(b.dataset.close)));
 document.querySelectorAll('[data-shot]').forEach(b=>b.addEventListener('click',()=>training.setShot(b.dataset.shot)));
 $('reset-btn').onclick=onReset;$('pause-btn').onclick=onPause;
 $('game-speed').oninput=e=>{training.settings.gameSpeed=+e.target.value;$('speed-output').textContent=(+e.target.value).toFixed(2)+'×';};
 $('gravity-scale').oninput=e=>{training.settings.gravityScale=+e.target.value;$('gravity-output').textContent=(+e.target.value).toFixed(2)+'×';};
 $('ball-bounce').oninput=e=>{training.settings.bounce=+e.target.value;$('bounce-output').textContent=(+e.target.value).toFixed(2);};
 $('unlimited-boost').onchange=e=>training.settings.unlimitedBoost=e.target.checked;
 $('hitboxes').onchange=e=>training.settings.hitboxes=e.target.checked;
 $('predictor').onchange=e=>training.settings.predictor=e.target.checked;
 $('save-shot').onclick=()=>download(training.saveShot($('shot-name').value),`${slug($('shot-name').value||'training-shot')}.json`);
 $('load-shot').onclick=()=>$('shot-file').click();$('shot-file').onchange=async e=>{if(!e.target.files[0])return;try{training.loadShot(JSON.parse(await e.target.files[0].text()));}catch(err){alert(err.message);}};
 $('tas-slot').onchange=e=>tas.slot=+e.target.value;
 $('tas-pause').onclick=()=>{tas.paused=!tas.paused;if(tas.paused)tas.playback=false;$('tas-pause').textContent=tas.paused?'RESUME':'PAUSE';};
 $('tas-step').onclick=()=>{tas.paused=true;onStep();};
 $('tas-record').onclick=()=>{if(tas.recording){tas.stopRecording();$('tas-record').textContent='● RECORD';}else{tas.startRecording();$('tas-record').textContent='■ STOP';$('tas-pause').textContent='PAUSE';}};
 $('tas-play').onclick=()=>{if(tas.cursor>=tas.frames.length)onSeek(0);if(tas.startPlayback()){$('tas-pause').textContent='PAUSE';}};
 $('save-state').onclick=()=>tas.saveState(tas.slot);
 $('load-state').onclick=()=>{if(!tas.loadState(tas.slot))alert(`Save slot ${tas.slot+1} is empty.`);else $('tas-pause').textContent='RESUME';};
 $('export-replay').onclick=()=>download(tas.export(),'boostball-tas.json');
 $('import-replay').onclick=()=>$('tas-file').click();
 $('tas-file').onchange=async e=>{if(!e.target.files[0])return;try{const n=tas.importData(JSON.parse(await e.target.files[0].text()));$('timeline').max=Math.max(0,n);$('timeline').value=0;updateEditor();alert(`Imported ${n} input frames.`);}catch(err){alert(err.message);}};
 $('timeline').oninput=e=>{onSeek(+e.target.value);$('tas-record').textContent='● RECORD';updateEditor();};
 const editorFields=['throttle','steer','pitch','yaw','roll'];
 function updateEditor(){const i=Math.min(tas.cursor,tas.frames.length-1),f=tas.frames[i];$('frame-count').textContent=tas.cursor;if(!f)return;for(const k of editorFields)$(`edit-${k}`).value=f.input[k]??0;$('edit-jump').checked=!!f.input.jump;$('edit-boost').checked=!!f.input.boost;}
 $('apply-frame').onclick=()=>{const i=Math.min(tas.cursor,tas.frames.length-1);if(i<0)return;const patch={};for(const k of editorFields)patch[k]=+$(`edit-${k}`).value;patch.jump=$('edit-jump').checked;patch.boost=$('edit-boost').checked;tas.editFrame(i,patch);$('tas-record').textContent='● RECORD';onSeek(i+1);};
 window.addEventListener('keydown',e=>{if(e.code==='F2'){e.preventDefault();$('training-panel').classList.toggle('hidden');}if(e.code==='F3'){e.preventDefault();$('tas-panel').classList.toggle('hidden');}if(e.code==='KeyC')onBallCam();if((e.code==='KeyR'||e.code==='Backspace')&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName))onReset();});
 return {show,hide,update({speed,boost,car,tick}){$('speed').textContent=Math.round(speed*3.6);$('boost-fill').style.width=`${boost}%`;$('boost-value').textContent=Math.round(boost);$('timeline').max=tas.frames.length;$('timeline').value=tas.cursor;$('frame-count').textContent=tas.cursor;$('tick-count').textContent=tick;$('pos-readout').textContent=fmt(car.translation());$('vel-readout').textContent=fmt(car.linvel());const r=car.rotation();$('rot-readout').textContent=`${r.x.toFixed(2)}, ${r.y.toFixed(2)}, ${r.z.toFixed(2)}`;}};
}
function fmt(v){return `${v.x.toFixed(2)}, ${v.y.toFixed(2)}, ${v.z.toFixed(2)}`;}
function slug(s){return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'')||'training-shot';}
