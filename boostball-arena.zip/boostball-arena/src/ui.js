export function bindUI({training,tas,onPause,onBallCam,onReset}){
 const $=id=>document.getElementById(id);
 const show=(id)=>$(id).classList.remove('hidden'),hide=id=>$(id).classList.add('hidden');
 document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>hide(b.dataset.close)));
 document.querySelectorAll('[data-shot]').forEach(b=>b.addEventListener('click',()=>training.setShot(b.dataset.shot)));
 $('reset-btn').onclick=onReset;$('pause-btn').onclick=onPause;
 $('game-speed').oninput=e=>{training.settings.gameSpeed=+e.target.value;$('speed-output').textContent=(+e.target.value).toFixed(2)+'×';};
 $('gravity-scale').oninput=e=>{training.settings.gravityScale=+e.target.value;$('gravity-output').textContent=(+e.target.value).toFixed(2)+'×';};
 $('ball-bounce').oninput=e=>{training.settings.bounce=+e.target.value;$('bounce-output').textContent=(+e.target.value).toFixed(2);};
 $('unlimited-boost').onchange=e=>training.settings.unlimitedBoost=e.target.checked;
 $('hitboxes').onchange=e=>training.settings.hitboxes=e.target.checked;
 $('predictor').onchange=e=>training.settings.predictor=e.target.checked;
 $('save-shot').onclick=()=>{const blob=training.saveShot($('shot-name').value);download(blob,`${slug($('shot-name').value||'training-shot')}.json`);};
 $('load-shot').onclick=()=>$('shot-file').click();$('shot-file').onchange=async e=>{if(!e.target.files[0])return;try{training.loadShot(JSON.parse(await e.target.files[0].text()));}catch(err){alert(err.message);}};
 $('tas-pause').onclick=()=>{tas.paused=!tas.paused;$('tas-pause').textContent=tas.paused?'RESUME':'PAUSE';};
 $('tas-step').onclick=()=>{tas.paused=true;window.dispatchEvent(new CustomEvent('tas-step'));};
 $('tas-record').onclick=()=>{tas.recording=!tas.recording;$('tas-record').textContent=tas.recording?'■ STOP':'● RECORD';};
 $('tas-play').onclick=()=>{tas.paused=false;};$('save-state').onclick=()=>{tas.saveState();$('tick-count').textContent=tas.tick;};$('load-state').onclick=()=>tas.loadState();
 $('export-replay').onclick=()=>download(tas.export(),'boostball-inputs.json');
 $('timeline').oninput=e=>{const f=tas.seek(+e.target.value);$('frame-count').textContent=tas.cursor;if(f)$('tick-count').textContent=f.tick;};
 window.addEventListener('keydown',e=>{if(e.code==='F2'){e.preventDefault();$('training-panel').classList.toggle('hidden');}if(e.code==='F3'){e.preventDefault();$('tas-panel').classList.toggle('hidden');}if(e.code==='KeyC')onBallCam();if(e.code==='KeyR'||e.code==='Backspace'){if(!['INPUT','TEXTAREA'].includes(document.activeElement.tagName))onReset();}});
 return {show,hide,update({speed,boost,car,tick}){$('speed').textContent=Math.round(speed*3.6);$('boost-fill').style.width=`${boost}%`;$('boost-value').textContent=Math.round(boost);$('timeline').max=tas.frames.length;$('timeline').value=tas.cursor;$('frame-count').textContent=tas.cursor;$('tick-count').textContent=tick;$('pos-readout').textContent=fmt(car.translation());$('vel-readout').textContent=fmt(car.linvel());$('rot-readout').textContent=fmt(car.rotation());}};
}
function fmt(v){return `${v.x.toFixed(2)}, ${v.y.toFixed(2)}, ${v.z.toFixed(2)}`;}
function slug(s){return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'')||'training-shot';}
function download(blob,name){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);}
